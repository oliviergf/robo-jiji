// ajouter meta donner sur les liens pour pour s'y retrouver

const links = [
  "https://www.kijiji.ca/rss-srp-appartement-condo/trois-rivieres/c37l1700150?radius=7.0&address=Nacho+Libre%2C+Rue+Beaubien+Est%2C+Montr%C3%A9al%2C+QC&ll=45.536765,-73.602646",
  "https://www.kijiji.ca/rss-srp-for-rent/quebec/c30349001l9001",
  "https://www.kijiji.ca/rss-srp-appartement-condo/gatineau/c37l1700186",
  "https://www.kijiji.ca/rss-srp-a-louer/gatineau/c30349001l1700186?radius=9.0&address=Gatineau%2C+QC&ll=45.476545,-75.701272",
  "https://www.kijiji.ca/rss-srp-a-louer/rimouski-bas-st-laurent/c30349001l1700250?radius=9.0&address=Rimouski%2C+QC&ll=48.438980,-68.534970",
  "https://www.kijiji.ca/rss-srp-a-louer/laurentides/c30349001l1700282?radius=9.0&address=Saint-J%C3%A9r%C3%B4me%2C+QC&ll=45.775357,-74.004948",
  "https://www.kijiji.ca/rss-srp-a-louer/laval-rive-nord/c30349001l1700278?radius=9.0&address=Laval%2C+QC&ll=45.606649,-73.712409",
  "https://www.kijiji.ca/rss-srp-a-louer/trois-rivieres/c30349001l1700150?radius=9.0&address=2950+Rue+de+la+Sidbec+N%2C+Trois-Rivi%C3%A8res%2C+QC+G8Z+4E1%2C+Canada&ll=46.337804,-72.584433",
  "https://www.kijiji.ca/rss-srp-a-louer/ville-de-quebec/c30349001l1700124?radius=9.0&address=409+Rue+du+Moulin%2C+Saint-Augustin-de-Desmaures%2C+QC+G3A+2R2%2C+Canada&ll=46.741522,-71.465473",
  "https://www.kijiji.ca/rss-srp-appartement-condo/quebec/c37l9001",
  "https://www.kijiji.ca/rss-srp-appartement-condo/grand-montreal/c37l80002?ad=offering",
  "https://www.kijiji.ca/rss-srp-a-louer/sherbrooke-qc/c30349001l1700156?radius=9.0&address=Sherbrooke%2C+QC&ll=45.404172,-71.892911",
  "https://www.kijiji.ca/rss-srp-a-louer/ville-de-montreal/c30349001l1700281?radius=9.0&address=6110+Rue+de+Chailly%2C+Saint-L%C3%A9onard%2C+QC+H1T+1J9%2C+Canada&ll=45.584154,-73.567284",
  "https://www.kijiji.ca/rss-srp-a-louer/ville-de-quebec/c30349001l1700124?radius=9.0&address=Qu%C3%A9bec%2C+QC&ll=46.813878,-71.207981",
  "https://www.kijiji.ca/rss-srp-appartement-condo/grand-montreal/c37l80002?ad=offering",
  "https://www.kijiji.ca/rss-srp-appartement-condo/ville-de-montreal/c37l1700281?radius=4.0&address=4670+Avenue+Dupuis%2C+Montr%C3%A9al%2C+QC+H3W+1N3%2C+Canada&ll=45.492763,-73.630455",
];

module.exports = links;
